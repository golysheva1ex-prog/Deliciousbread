# db.py
import aiosqlite
from typing import Optional, List, Tuple
import math

DB_PATH = "bot.db"

CREATE_USERS = """
CREATE TABLE IF NOT EXISTS users (
    user_id INTEGER PRIMARY KEY,
    phone TEXT UNIQUE,
    address TEXT,
    balance REAL DEFAULT 0
);
"""

CREATE_CATEGORIES = """
CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT UNIQUE NOT NULL
);
"""

CREATE_PRODUCTS = """
CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    price REAL NOT NULL,
    photo_file_id TEXT,
    FOREIGN KEY(category_id) REFERENCES categories(id) ON DELETE CASCADE
);
"""

CREATE_CART_ITEMS = """
CREATE TABLE IF NOT EXISTS cart_items (
    user_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    qty INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY (user_id, product_id),
    FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
);
"""

CREATE_ORDERS = """
CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    total REAL NOT NULL,
    status TEXT NOT NULL, -- pending, paid, canceled
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
"""

CREATE_ORDER_ITEMS = """
CREATE TABLE IF NOT EXISTS order_items (
    order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    title TEXT NOT NULL,
    price REAL NOT NULL,
    qty INTEGER NOT NULL,
    FOREIGN KEY(order_id) REFERENCES orders(id) ON DELETE CASCADE
);
"""

async def _migrate_users_add_username(db: aiosqlite.Connection):
    # Добавляет колонку username, если её ещё нет
    cur = await db.execute("PRAGMA table_info(users)")
    cols = [row[1] for row in await cur.fetchall()]
    if "username" not in cols:
        try:
            await db.execute("ALTER TABLE users ADD COLUMN username TEXT")
            await db.commit()
        except Exception:
            pass

async def init_db():
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(CREATE_USERS)
        await _migrate_users_add_username(db)
        await db.execute(CREATE_CATEGORIES)
        await db.execute(CREATE_PRODUCTS)
        await db.execute(CREATE_CART_ITEMS)
        await db.execute(CREATE_ORDERS)
        await db.execute(CREATE_ORDER_ITEMS)
        await db.commit()

# ========== Users ==========
async def get_user(user_id: int) -> Optional[tuple]:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT user_id, phone, address, balance, username FROM users WHERE user_id = ?", (user_id,))
        return await cur.fetchone()

async def create_user(user_id: int, phone: str, address: Optional[str] = None, username: Optional[str] = None) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT OR IGNORE INTO users (user_id, phone, address, username) VALUES (?, ?, ?, ?)",
            (user_id, phone, address, username)
        )
        if address is not None:
            await db.execute("UPDATE users SET address = ? WHERE user_id = ?", (address, user_id))
        if username is not None:
            await db.execute("UPDATE users SET username = ? WHERE user_id = ?", (username, user_id))
        await db.commit()

async def set_address(user_id: int, address: str) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE users SET address = ? WHERE user_id = ?", (address, user_id))
        await db.commit()

async def set_username(user_id: int, username: str) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE users SET username = ? WHERE user_id = ?", (username, user_id))
        await db.commit()

async def update_balance(user_id: int, amount: float) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE users SET balance = balance + ? WHERE user_id = ?", (amount, user_id))
        await db.commit()

# ========== Catalog: categories ==========
async def add_category(title: str) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("INSERT OR IGNORE INTO categories (title) VALUES (?)", (title,))
        await db.commit()
        cur = await db.execute("SELECT id FROM categories WHERE title = ?", (title,))
        row = await cur.fetchone()
        return row[0]

async def list_categories() -> List[Tuple[int, str]]:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT id, title FROM categories ORDER BY title")
        return await cur.fetchall()

# ========== Catalog: products ==========
async def add_product(category_id: int, title: str, price: float, photo_file_id: str) -> int:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO products (category_id, title, price, photo_file_id) VALUES (?, ?, ?, ?)",
            (category_id, title, price, photo_file_id)
        )
        await db.commit()
        cur = await db.execute("SELECT last_insert_rowid()")
        row = await cur.fetchone()
        return row[0]

async def list_products_by_category(category_id: int) -> List[Tuple[int, str, float, str]]:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT id, title, price, photo_file_id FROM products WHERE category_id = ? ORDER BY id DESC",
            (category_id,)
        )
        return await cur.fetchall()

async def get_product(product_id: int) -> Optional[tuple]:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT id, category_id, title, price, photo_file_id FROM products WHERE id = ?",
            (product_id,)
        )
        return await cur.fetchone()

# Пагинация и поиск (если используете)
async def list_products_by_category_paginated(category_id: int, page: int = 1, per_page: int = 6, query: str | None = None):
    where = "WHERE category_id = ?"
    params = [category_id]
    if query:
        where += " AND title LIKE ?"
        params.append(f"%{query}%")
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(f"SELECT COUNT(*) FROM products {where}", tuple(params))
        total_items = (await cur.fetchone())[0]
        total_pages = max(1, math.ceil(total_items / per_page))
        page = max(1, min(page, total_pages))
        offset = (page - 1) * per_page
        cur = await db.execute(
            f"SELECT id, title, price, photo_file_id FROM products {where} ORDER BY id DESC LIMIT ? OFFSET ?",
            tuple(params + [per_page, offset])
        )
        items = await cur.fetchall()
        return items, total_pages, total_items, page

async def search_products_paginated(page: int = 1, per_page: int = 6, query: str | None = None):
    where = ""
    params: list = []
    if query:
        where = "WHERE title LIKE ?"
        params.append(f"%{query}%")
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(f"SELECT COUNT(*) FROM products {where}", tuple(params))
        total_items = (await cur.fetchone())[0]
        total_pages = max(1, math.ceil(total_items / per_page))
        page = max(1, min(page, total_pages))
        offset = (page - 1) * per_page
        cur = await db.execute(
            f"SELECT id, title, price, photo_file_id FROM products {where} ORDER BY id DESC LIMIT ? OFFSET ?",
            tuple(params + [per_page, offset])
        )
        items = await cur.fetchall()
        return items, total_pages, total_items, page

# ========== Cart ==========
async def add_to_cart(user_id: int, product_id: int, qty: int = 1):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO cart_items (user_id, product_id, qty) VALUES (?, ?, ?) "
            "ON CONFLICT(user_id, product_id) DO UPDATE SET qty = qty + excluded.qty",
            (user_id, product_id, qty)
        )
        await db.commit()

async def set_cart_qty(user_id: int, product_id: int, qty: int):
    async with aiosqlite.connect(DB_PATH) as db:
        if qty <= 0:
            await db.execute("DELETE FROM cart_items WHERE user_id = ? AND product_id = ?", (user_id, product_id))
        else:
            await db.execute(
                "INSERT INTO cart_items (user_id, product_id, qty) VALUES (?, ?, ?) "
                "ON CONFLICT(user_id, product_id) DO UPDATE SET qty = excluded.qty",
                (user_id, product_id, qty)
            )
        await db.commit()

async def get_cart(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute(
            "SELECT ci.product_id, ci.qty, p.title, p.price "
            "FROM cart_items ci JOIN products p ON p.id = ci.product_id "
            "WHERE ci.user_id = ?",
            (user_id,)
        )
        rows = await cur.fetchall()
        return [(r[0], r[1], r[2], r[3]) for r in rows]

async def clear_cart(user_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM cart_items WHERE user_id = ?", (user_id,))
        await db.commit()

async def remove_item(user_id: int, product_id: int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("DELETE FROM cart_items WHERE user_id = ? AND product_id = ?", (user_id, product_id))
        await db.commit()

# ========== Orders ==========
async def create_order(user_id: int, address: str, items: List[Tuple[int, int, str, float]]) -> int:
    total = sum(qty * price for _, qty, _, price in items)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO orders (user_id, total, status, address) VALUES (?, ?, 'pending', ?)",
            (user_id, total, address)
        )
        await db.commit()
        cur = await db.execute("SELECT last_insert_rowid()")
        row = await cur.fetchone()
        order_id = row[0]
        for product_id, qty, title, price in items:
            await db.execute(
                "INSERT INTO order_items (order_id, product_id, title, price, qty) VALUES (?, ?, ?, ?, ?)",
                (order_id, product_id, title, price, qty)
            )
        await db.commit()
        return order_id

async def set_order_status(order_id: int, status: str):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE orders SET status = ? WHERE id = ?", (status, order_id))
        await db.commit()
# db.py — ДОБАВИТЕ эти функции

# Список пользователей для админа: [(user_id, phone, address, balance, username)]
async def list_users() -> List[Tuple[int, str, str, float, str]]:
    async with aiosqlite.connect(DB_PATH) as db:
        cur = await db.execute("SELECT user_id, phone, address, balance, COALESCE(username, '') FROM users ORDER BY user_id")
        return await cur.fetchall()

# Перенести товар в другую категорию
async def set_product_category(product_id: int, new_category_id: int) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("UPDATE products SET category_id = ? WHERE id = ?", (new_category_id, product_id))
        await db.commit()
