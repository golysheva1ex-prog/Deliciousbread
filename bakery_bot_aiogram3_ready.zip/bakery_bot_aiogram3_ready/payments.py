import os
import asyncio
from dotenv import load_dotenv
from yookassa import Configuration, Payment

load_dotenv()
Configuration.account_id = os.getenv("YOOKASSA_SHOP_ID")
Configuration.secret_key = os.getenv("YOOKASSA_SECRET_KEY")
RETURN_URL = os.getenv("RETURN_URL", "https://t.me/your_bot_username")

async def _to_thread(func, *args, **kwargs):
    return await asyncio.to_thread(func, *args, **kwargs)

async def create_payment(user_id: int, amount: float) -> tuple[str, str]:
    """
    Создает платеж в ЮKassa, возвращает (payment_id, confirmation_url).
    """
    payload = {
        "amount": {"value": f"{amount:.2f}", "currency": "RUB"},
        "confirmation": {"type": "redirect", "return_url": RETURN_URL},
        "capture": True,
        "description": f"Пополнение баланса для user_id={user_id}",
        "metadata": {"user_id": user_id},
    }
    payment = await _to_thread(Payment.create, payload)
    return payment.id, payment.confirmation.confirmation_url

async def get_payment_status(payment_id: str) -> str:
    """
    Возвращает статус платежа: pending, waiting_for_capture, succeeded, canceled, etc.
    """
    payment = await _to_thread(Payment.find_one, payment_id)
    return payment.status
