# keyboards.py
from aiogram.types import (
    ReplyKeyboardMarkup,
    KeyboardButton,
    InlineKeyboardMarkup,
    InlineKeyboardButton,
)

def main_menu_kb(is_admin: bool = False) -> ReplyKeyboardMarkup:
    """
    Динамическое главное меню:
    - «🛠 Админ» показывается только администраторам (is_admin=True).
    - «📋 Меню» — вход в каталог категорий.
    - Кнопка «Главное меню» удалена по требованию.
    """
    rows = [
        [KeyboardButton(text="📋 Меню")],
        [KeyboardButton(text="📝 Регистрация"), KeyboardButton(text="💰 Баланс")],
        [KeyboardButton(text="🧺 Корзина"), KeyboardButton(text="📦 Оформить заказ")],
        [KeyboardButton(text="👤 Мой профиль"), KeyboardButton(text="🆘 Помощь")],
    ]
    if is_admin:
        rows.append([KeyboardButton(text="🛠 Админ")])
    return ReplyKeyboardMarkup(keyboard=rows, resize_keyboard=True)

def admin_menu_kb() -> ReplyKeyboardMarkup:
    """
    Админ-меню с выходом из админ-режима.
    """
    return ReplyKeyboardMarkup(
        keyboard=[
            [KeyboardButton(text="➕ Категория"), KeyboardButton(text="➕ Товар")],
            [KeyboardButton(text="🔁 Перенести товар"), KeyboardButton(text="📋 Пользователи")],
            [KeyboardButton(text="⬅️ Выйти из админ-режима")],
        ],
        resize_keyboard=True
    )

def categories_kb(categories: list[tuple[int, str]]) -> InlineKeyboardMarkup:
    rows = []
    for cat_id, title in categories:
        rows.append([InlineKeyboardButton(text=title, callback_data=f"cat:{cat_id}:p:1")])
    if not rows:
        rows = [[InlineKeyboardButton(text="Категории не найдены", callback_data="noop")]]
    return InlineKeyboardMarkup(inline_keyboard=rows)

def products_page_kb(cat_id: int, page: int, total_pages: int, query_token: str | None = None) -> InlineKeyboardMarkup:
    """
    Навигация по страницам товаров категории.
    """
    q = f":q:{query_token}" if query_token else ""
    prev_btn = InlineKeyboardButton(text="⬅️", callback_data=f"pg:{cat_id}:p:{max(1, page-1)}{q}")
    next_btn = InlineKeyboardButton(text="➡️", callback_data=f"pg:{cat_id}:p:{page+1}{q}")
    info_btn = InlineKeyboardButton(text=f"{page}/{total_pages}", callback_data="noop")
    back_btn = InlineKeyboardButton(text="⬅️ К категориям", callback_data="back:cats")
    row_nav = [prev_btn, info_btn, next_btn] if total_pages > 1 else [info_btn]
    return InlineKeyboardMarkup(inline_keyboard=[row_nav, [back_btn]])

def add_product_btn(product_id: int) -> InlineKeyboardMarkup:
    """
    Кнопка добавления товара в корзину под карточкой товара.
    """
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="➕ В корзину", callback_data=f"add:{product_id}")]
    ])

def cart_item_controls_kb(product_id: int) -> InlineKeyboardMarkup:
    """
    Управление количеством позиции в корзине.
    """
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="➖", callback_data=f"cart:sub:{product_id}"),
            InlineKeyboardButton(text="➕", callback_data=f"cart:add:{product_id}"),
            InlineKeyboardButton(text="🗑 Удалить", callback_data=f"cart:del:{product_id}"),
        ]
    ])

def cart_controls_kb() -> InlineKeyboardMarkup:
    """
    Общая кнопка для очистки корзины.
    """
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="🧹 Очистить корзину", callback_data="cart:clear")]
    ])

def checkout_kb(order_id: int) -> InlineKeyboardMarkup:
    """
    Оформление заказа: фиктивная оплата/отмена.
    """
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="💳 Оплатить через ЮKassa (фиктивно)", callback_data=f"payfake:{order_id}")],
        [InlineKeyboardButton(text="❌ Отменить заказ", callback_data=f"cancel_order:{order_id}")]
    ])

def checkout_confirm_kb() -> InlineKeyboardMarkup:
    """
    Подтверждение адреса перед фиктивной оплатой.
    """
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✅ Подтвердить адрес", callback_data="checkout:confirm_address")],
        [InlineKeyboardButton(text="✏️ Изменить адрес", callback_data="checkout:change_address")],
        [InlineKeyboardButton(text="❌ Отменить", callback_data="checkout:cancel")],
    ])

def profile_menu_kb() -> InlineKeyboardMarkup:
    """
    Меню профиля: изменение адреса/имени.
    """
    return InlineKeyboardMarkup(inline_keyboard=[
        [InlineKeyboardButton(text="✏️ Изменить адрес", callback_data="profile:edit_address")],
        [InlineKeyboardButton(text="✏️ Изменить имя", callback_data="profile:edit_username")]
    ])

def balance_topup_kb() -> InlineKeyboardMarkup:
    """
    Фиктивное пополнение баланса.
    """
    return InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="➕ 100 ₽", callback_data="topup:100"),
            InlineKeyboardButton(text="➕ 300 ₽", callback_data="topup:300"),
            InlineKeyboardButton(text="➕ 500 ₽", callback_data="topup:500"),
        ],
        [
            InlineKeyboardButton(text="➕ 1000 ₽", callback_data="topup:1000"),
            InlineKeyboardButton(text="➕ 2000 ₽", callback_data="topup:2000"),
        ]
    ])
