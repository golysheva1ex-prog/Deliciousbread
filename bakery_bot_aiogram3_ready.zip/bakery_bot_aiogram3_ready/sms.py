import os
from dotenv import load_dotenv
from aiohttp import ClientSession

load_dotenv()
SMS_API_ID = os.getenv("SMS_RU_API_ID")

async def send_sms(phone: str, message: str) -> bool:
    """
    Отправка SMS через sms.ru
    Возвращает True при статусе OK.
    """
    if not SMS_API_ID:
        return False
    url = "https://sms.ru/sms/send"
    data = {
        "api_id": SMS_API_ID,
        "to": phone,
        "msg": message,
        "json": 1
    }
    async with ClientSession() as session:
        async with session.post(url, data=data, timeout=20) as resp:
            j = await resp.json()
            return j.get("status") == "OK"
