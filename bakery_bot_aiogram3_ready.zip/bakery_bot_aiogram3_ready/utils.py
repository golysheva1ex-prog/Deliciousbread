import re
from time import time

PHONE_RE = re.compile(r"^\+7\d{10}$")  # формат РФ: +7XXXXXXXXXX

def valid_phone(phone: str) -> bool:
    return bool(PHONE_RE.match(phone.strip()))

# Простейший троттлинг для отправки SMS (не чаще раз в 30 сек)
_sms_throttle = {}

def can_send_sms(user_id: int, cooldown_sec: int = 30) -> bool:
    now = time()
    ts = _sms_throttle.get(user_id, 0)
    if now - ts >= cooldown_sec:
        _sms_throttle[user_id] = now
        return True
    return False
