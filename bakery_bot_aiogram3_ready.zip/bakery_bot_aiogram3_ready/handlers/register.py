# handlers/register.py
import re
from aiogram import Router, F
from aiogram.types import Message
from aiogram.fsm.state import StatesGroup, State
from aiogram.fsm.context import FSMContext

from db import create_user, set_address, set_username

router = Router(name="register")

PHONE_RE = re.compile(r"^\+7\d{10}$")  # формат РФ +7XXXXXXXXXX

class RegStates(StatesGroup):
    name = State()
    phone = State()
    address = State()

@router.message(F.text == "/register")
@router.message(F.text == "📝 Регистрация")
async def start_register(message: Message, state: FSMContext):
    await message.answer("Введите ваше имя (как отображать в заказах):")
    await state.set_state(RegStates.name)

@router.message(RegStates.name)
async def input_name(message: Message, state: FSMContext):
    name = message.text.strip()
    if not name:
        await message.answer("Имя не может быть пустым. Введите ваше имя:")
        return
    await state.update_data(name=name)
    await message.answer("Введите номер телефона в формате +7XXXXXXXXXX:")
    await state.set_state(RegStates.phone)

@router.message(RegStates.phone)
async def input_phone(message: Message, state: FSMContext):
    phone = message.text.strip()
    if not PHONE_RE.match(phone):
        await message.answer("Некорректный формат телефона. Пример: +79991234567\nВведите номер снова:")
        return
    await state.update_data(phone=phone)
    await message.answer("Введите адрес доставки (улица, дом, кв/офис):")
    await state.set_state(RegStates.address)

@router.message(RegStates.address)
async def input_address(message: Message, state: FSMContext):
    address = message.text.strip()
    if not address:
        await message.answer("Адрес не может быть пустым. Введите адрес доставки:")
        return

    data = await state.get_data()
    user_id = message.from_user.id
    name = data["name"]
    phone = data["phone"]

    # Создание/обновление пользователя
    await create_user(user_id, phone, address, name)
    await set_address(user_id, address)
    await set_username(user_id, name)

    await message.answer("🎉 Регистрация завершена! Данные сохранены в вашем профиле.")
    await state.clear()
