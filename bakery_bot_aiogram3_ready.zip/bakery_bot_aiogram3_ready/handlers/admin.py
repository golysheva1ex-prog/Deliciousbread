# handlers/admin.py
import os
from aiogram import Router, F
from aiogram.types import Message
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State

from db import (
    add_category,
    list_categories,
    add_product,
    set_product_category,
    list_users,
)
from keyboards import admin_menu_kb, main_menu_kb

router = Router(name="admin")

def is_admin(user_id: int) -> bool:
    """
    Проверка, что user_id находится в ADMIN_IDS (строка вида "1,2,3") из .env.
    """
    admins = os.getenv("ADMIN_IDS", "")
    ids = set()
    for x in admins.split(","):
        x = x.strip()
        if x.isdigit():
            ids.add(int(x))
    return user_id in ids

# ================== Выход из админ-режима ==================

@router.message(F.text == "⬅️ Выйти из админ-режима")
async def exit_admin_mode(message: Message, state: FSMContext):
    """
    Очищает любые активные FSM-состояния админских сценариев и возвращает в главное меню.
    """
    await state.clear()
    # Админ увидит главное меню с кнопкой «🛠 Админ», пользователь — без неё
    await message.answer(
        "Вы вышли из админ-режима.",
        reply_markup=main_menu_kb(is_admin=is_admin(message.from_user.id))
    )

# ================== Админ-меню (вход) ==================

@router.message(F.text == "🛠 Админ")
@router.message(F.text == "Админ")  # на случай ручного ввода
async def open_admin_menu(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer("⛔ Доступ запрещён. Добавьте свой user_id в ADMIN_IDS в .env и перезапустите бота.")
        return
    await message.answer("Админ-меню:", reply_markup=admin_menu_kb())

# ================== Добавление категории ==================

class AddCategorySG(StatesGroup):
    title = State()

@router.message(F.text == "➕ Категория")
async def add_category_start(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    await message.answer("Введите название категории:")
    await state.set_state(AddCategorySG.title)

@router.message(AddCategorySG.title)
async def add_category_title(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        await state.clear()
        return
    title = message.text.strip()
    if not title:
        await message.answer("Название не может быть пустым. Введите снова:")
        return
    cat_id = await add_category(title)
    await message.answer(f"✅ Категория добавлена. ID={cat_id}")
    await state.clear()

# ================== Добавление товара ==================

class AddProductSG(StatesGroup):
    cat_id = State()
    title = State()
    price = State()
    photo = State()

@router.message(F.text == "➕ Товар")
async def add_product_start(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    cats = await list_categories()
    if not cats:
        await message.answer("Сначала добавьте категорию (кнопка «➕ Категория»).")
        return
    text = "Введите ID категории из списка:\n" + "\n".join([f"{cid}: {title}" for cid, title in cats])
    await message.answer(text)
    await state.set_state(AddProductSG.cat_id)

@router.message(AddProductSG.cat_id)
async def add_product_cat(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        await state.clear()
        return
    try:
        cat_id = int(message.text.strip())
    except ValueError:
        await message.answer("Введите числовой ID категории из списка.")
        return
    await state.update_data(cat_id=cat_id)
    await message.answer("Введите название товара:")
    await state.set_state(AddProductSG.title)

@router.message(AddProductSG.title)
async def add_product_title(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        await state.clear()
        return
    title = message.text.strip()
    if not title:
        await message.answer("Название не может быть пустым. Введите снова:")
        return
    await state.update_data(title=title)
    await message.answer("Введите цену (например 199.90):")
    await state.set_state(AddProductSG.price)

@router.message(AddProductSG.price)
async def add_product_price(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        await state.clear()
        return
    try:
        price = float(message.text.replace(",", "."))
    except ValueError:
        await message.answer("Некорректная цена. Введите число, например 199.90")
        return
    await state.update_data(price=price)
    await message.answer("Отправьте фото товара как изображение (не как файл).")
    await state.set_state(AddProductSG.photo)

@router.message(AddProductSG.photo, F.photo)
async def add_product_photo(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        await state.clear()
        return
    photo_id = message.photo[-1].file_id
    data = await state.get_data()
    prod_id = await add_product(data["cat_id"], data["title"], data["price"], photo_id)
    await message.answer(f"✅ Товар добавлен. ID={prod_id}")
    await state.clear()

@router.message(AddProductSG.photo)
async def add_product_photo_wrong(message: Message):
    if is_admin(message.from_user.id):
        await message.answer("Пришлите, пожалуйста, фото как изображение.")

# ================== Перенос товара в другую категорию ==================

class MoveProductSG(StatesGroup):
    product_id = State()
    new_cat_id = State()

@router.message(F.text == "🔁 Перенести товар")
async def move_product_start(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    await message.answer("Введите ID товара, который нужно перенести:")
    await state.set_state(MoveProductSG.product_id)

@router.message(MoveProductSG.product_id)
async def move_product_get_id(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        await state.clear()
        return
    try:
        pid = int(message.text.strip())
    except ValueError:
        await message.answer("Введите числовой ID товара:")
        return
    cats = await list_categories()
    if not cats:
        await message.answer("Категории отсутствуют. Сначала добавьте категорию.")
        await state.clear()
        return
    text = "Введите ID новой категории из списка:\n" + "\n".join([f"{cid}: {title}" for cid, title in cats])
    await state.update_data(product_id=pid)
    await message.answer(text)
    await state.set_state(MoveProductSG.new_cat_id)

@router.message(MoveProductSG.new_cat_id)
async def move_product_apply(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        await state.clear()
        return
    data = await state.get_data()
    try:
        new_cid = int(message.text.strip())
    except ValueError:
        await message.answer("Введите числовой ID категории:")
        return
    await set_product_category(data["product_id"], new_cid)
    await state.clear()
    await message.answer("✅ Товар перенесён в новую категорию.")

# ================== Список пользователей ==================

@router.message(F.text == "📋 Пользователи")
async def list_users_cmd(message: Message):
    if not is_admin(message.from_user.id):
        return
    users = await list_users()
    if not users:
        await message.answer("Пользователей пока нет.")
        return
    # Формат: Имя — Телефон
    lines = []
    for uid, phone, address, balance, username in users[:500]:  # ограничим вывод
        name = username or "не указано"
        phone_show = phone or "—"
        lines.append(f"{name} — {phone_show}")
    text = "Зарегистрированные пользователи:\n" + "\n".join(lines)
    await message.answer(text)
