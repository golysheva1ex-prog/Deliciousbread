# handlers/catalog.py — ЗАМЕНИТЕ СОДЕРЖИМОЕ ФАЙЛА ЭТИМ

from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State
import os
import secrets

from db import (
    list_categories,
    list_products_by_category_paginated,
    search_products_paginated,
    add_category, add_product, get_product, add_to_cart
)
from keyboards import categories_kb, products_page_kb, add_product_btn, main_menu_kb

router = Router(name="catalog")

# Память фильтра: user_id -> token -> query
# Чтобы не класть длинные строки в callback_data
FILTER_CACHE: dict[int, dict[str, str]] = {}

def is_admin(user_id: int) -> bool:
    admins = os.getenv("ADMIN_IDS", "")
    ids = {int(x.strip()) for x in admins.split(",") if x.strip().isdigit()}
    return user_id in ids

# ========= Пользовательский каталог =========

@router.message(F.text == "🛍 Каталог")
async def open_catalog(message: Message):
    cats = await list_categories()
    await message.answer("Выберите категорию:", reply_markup=categories_kb(cats))

@router.callback_query(F.data.startswith("back:cats"))
async def back_to_cats(call: CallbackQuery):
    await call.answer()
    cats = await list_categories()
    await call.message.edit_text("Выберите категорию:", reply_markup=categories_kb(cats))

@router.callback_query(F.data.startswith("cat:") | F.data.startswith("pg:"))
async def open_category(call: CallbackQuery):
    """
    cat:{cat_id}:p:{page}
    pg:{cat_id}:p:{page}[:q:{token}]
    """
    await call.answer()
    data = call.data
    query_token = None

    if data.startswith("cat:"):
        _, cat_id, _, page = data.split(":")
    else:
        # pg:{cat_id}:p:{page}[:q:{token}]
        parts = data.split(":")
        # ['pg', cat_id, 'p', page, ('q', token)?]
        cat_id = parts[1]
        page = parts[3]
        if len(parts) >= 6 and parts[4] == "q":
            query_token = parts[5]

    cat_id = int(cat_id)
    page = int(page)

    # Получим строку фильтра из памяти, если есть
    user_filters = FILTER_CACHE.get(call.from_user.id, {})
    query = user_filters.get(query_token) if query_token else None

    products, total_pages, total_items, page = await list_products_by_category_paginated(
        category_id=cat_id, page=page, per_page=6, query=query
    )

    if total_items == 0:
        await call.message.edit_text("Нет товаров по этому запросу в этой категории.", reply_markup=categories_kb(await list_categories()))
        return

    # Заголовок с информацией
    header = f"Категория #{cat_id}. Найдено: {total_items}. Стр. {page}/{total_pages}"
    # Обновим текст и кнопки навигации
    await call.message.edit_text(header, reply_markup=products_page_kb(cat_id, page, total_pages, query_token=query_token))

    # Показ товаров (в виде карточек)
    for p_id, title, price, photo_id in products:
        caption = f"{title}\nЦена: {price:.2f} ₽"
        if photo_id:
            await call.message.answer_photo(photo_id, caption=caption, reply_markup=add_product_btn(p_id))
        else:
            await call.message.answer(caption, reply_markup=add_product_btn(p_id))

@router.callback_query(F.data.startswith("add:"))
async def add_to_cart_cb(call: CallbackQuery):
    await call.answer("Добавлено в корзину")
    product_id = int(call.data.split(":")[1])
    product = await get_product(product_id)
    if not product:
        await call.message.answer("Товар не найден.")
        return
    await add_to_cart(call.from_user.id, product_id, 1)

# ========= Поиск =========

class SearchSG(StatesGroup):
    query = State()

@router.message(F.text == "🔎 Поиск")
async def start_search(message: Message, state: FSMContext):
    await message.answer("Введите текст для поиска по всем товарам:")
    await state.set_state(SearchSG.query)

@router.message(SearchSG.query)
async def do_search(message: Message, state: FSMContext):
    query = message.text.strip()
    await state.clear()
    if not query:
        await message.answer("Пустой запрос. Попробуйте ещё раз.", reply_markup=main_menu_kb())
        return

    # Сохраняем фильтр в память и выдаём токен
    token = secrets.token_urlsafe(6)
    FILTER_CACHE.setdefault(message.from_user.id, {})[token] = query

    # Покажем первую страницу результатов
    items, total_pages, total_items, page = await search_products_paginated(page=1, per_page=6, query=query)
    if total_items == 0:
        await message.answer("Ничего не найдено.", reply_markup=main_menu_kb())
        return

    header = f"Поиск: «{query}». Найдено: {total_items}. Стр. {page}/{total_pages}"
    # Здесь cat_id не применим — используем псевдо cat_id = 0 для глобального списка
    # Для простоты — переиспользуем ту же навигацию (но обработчик глобальных страниц можно вынести отдельно).
    # В этом примере оставим только выдачу карточек первой страницы без кнопок пагинации для глобального поиска,
    # либо сделайте отдельный обработчик с префиксом gpg: для глобальной пагинации.
    await message.answer(header)
    for p_id, title, price, photo_id in items:
        caption = f"{title}\nЦена: {price:.2f} ₽"
        if photo_id:
            await message.answer_photo(photo_id, caption=caption, reply_markup=add_product_btn(p_id))
        else:
            await message.answer(caption, reply_markup=add_product_btn(p_id))

# ========= Админские команды (без изменений логики; оставлены для полноты) =========

class AddCategorySG(StatesGroup):
    title = State()

class AddProductSG(StatesGroup):
    cat_id = State()
    title = State()
    price = State()
    photo = State()

@router.message(F.text == "/add_category")
async def add_category_cmd(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    await message.answer("Введите название категории:")
    await state.set_state(AddCategorySG.title)

@router.message(AddCategorySG.title)
async def add_category_title(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        await state.clear()
        return
    cat_id = await add_category(message.text.strip())
    await message.answer(f"✅ Категория добавлена. ID={cat_id}")
    await state.clear()

@router.message(F.text == "/add_product")
async def add_product_cmd(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        return
    cats = await list_categories()
    if not cats:
        await message.answer("Сначала добавьте категорию: /add_category")
        return
    text = "Введите ID категории из списка:\n" + "\n".join([f"{cid}: {title}" for cid, title in cats])
    await message.answer(text)
    await state.set_state(AddProductSG.cat_id)

@router.message(AddProductSG.cat_id)
async def add_product_cat(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        await state.clear()
        return
    try:
        cat_id = int(message.text.strip())
    except ValueError:
        await message.answer("Введите числовой ID категории.")
        return
    await state.update_data(cat_id=cat_id)
    await message.answer("Введите название товара:")
    await state.set_state(AddProductSG.title)

@router.message(AddProductSG.title)
async def add_product_title(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        await state.clear()
        return
    await state.update_data(title=message.text.strip())
    await message.answer("Введите цену (число):")
    await state.set_state(AddProductSG.price)

@router.message(AddProductSG.price)
async def add_product_price(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        await state.clear()
        return
    try:
        price = float(message.text.replace(",", "."))
    except ValueError:
        await message.answer("Некорректная цена. Введите число, например 199.90")
        return
    await state.update_data(price=price)
    await message.answer("Отправьте фото товара (как фото, не как файл).")
    await state.set_state(AddProductSG.photo)

@router.message(AddProductSG.photo, F.photo)
async def add_product_photo(message: Message, state: FSMContext):
    if not is_admin(message.from_user.id):
        await state.clear()
        return
    photo = message.photo[-1]
    photo_id = photo.file_id
    data = await state.get_data()
    prod_id = await add_product(data["cat_id"], data["title"], data["price"], photo_id)
    await message.answer(f"✅ Товар добавлен. ID={prod_id}")
    await state.clear()

@router.message(AddProductSG.photo)
async def add_product_photo_wrong(message: Message):
    if is_admin(message.from_user.id):
        await message.answer("Пришлите, пожалуйста, фото.")
