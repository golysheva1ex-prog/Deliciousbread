from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from db import get_user, log_payment, update_balance, get_payment, update_payment_status
from keyboards import amounts_keyboard, payment_actions_keyboard
from payments import create_payment, get_payment_status

router = Router(name="pay")

@router.message(F.text == "/pay")
async def cmd_pay(message: Message):
    user = await get_user(message.from_user.id)
    if not user:
        await message.answer("❌ Вы не зарегистрированы. Используйте /register")
        return
    await message.answer("Выберите сумму пополнения:", reply_markup=amounts_keyboard())

@router.callback_query(F.data.startswith("pay:"))
async def choose_amount(call: CallbackQuery):
    await call.answer()
    amount = float(call.data.split(":")[1])
    user_id = call.from_user.id

    payment_id, pay_url = await create_payment(user_id, amount)
    await log_payment(payment_id, user_id, amount, status="pending")

    await call.message.edit_text(
        f"Создан платёж на {amount:.2f} ₽.\n"
        f"Нажмите 'Оплатить', затем после оплаты — 'Проверить оплату'.",
        reply_markup=payment_actions_keyboard(payment_id, pay_url),
        disable_web_page_preview=True
    )

@router.callback_query(F.data.startswith("check:"))
async def check_payment(call: CallbackQuery):
    await call.answer("Проверяю статус...")
    payment_id = call.data.split(":")[1]
    info = await get_payment(payment_id)
    if not info:
        await call.message.reply_text("Платёж не найден.")
        return

    _, user_id, amount, status, _ = info
    if status == "succeeded":
        await call.message.reply_text("✅ Платёж уже подтверждён.")
        return

    new_status = await get_payment_status(payment_id)

    if new_status == "succeeded":
        await update_payment_status(payment_id, "succeeded")
        await update_balance(user_id, float(amount))
        await call.message.edit_text(f"✅ Оплата подтверждена! Баланс пополнен на {amount:.2f} ₽.")
    elif new_status in ("canceled", "expired"):
        await update_payment_status(payment_id, new_status)
        await call.message.edit_text(f"❌ Платёж {new_status}. Попробуйте создать новый.")
    else:
        await call.message.reply_text(f"ℹ️ Текущий статус: {new_status}. Оплатите и нажмите 'Проверить оплату' снова.")
