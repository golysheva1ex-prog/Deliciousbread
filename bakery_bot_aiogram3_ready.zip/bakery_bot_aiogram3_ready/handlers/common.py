# handlers/common.py
import os
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery

from db import get_user, list_categories, update_balance
from keyboards import (
    main_menu_kb,
    categories_kb,
    admin_menu_kb,
    balance_topup_kb,
)

router = Router(name="common")

def is_admin(user_id: int) -> bool:
    admins = os.getenv("ADMIN_IDS", "")
    ids = set()
    for x in admins.split(","):
        x = x.strip()
        if x.isdigit():
            ids.add(int(x))
    return user_id in ids

@router.message(F.text == "/start")
async def cmd_start(message: Message):
    await message.answer(
        "👋 Привет! Я бот пекарни.",
        reply_markup=main_menu_kb(is_admin=is_admin(message.from_user.id))
    )

@router.message(F.text == "/menu")
async def show_main_menu_cmd(message: Message):
    await message.answer(
        "Главное меню:",
        reply_markup=main_menu_kb(is_admin=is_admin(message.from_user.id))
    )

@router.message(F.text == "📋 Меню")
async def open_menu(message: Message):
    cats = await list_categories()
    await message.answer("Выберите категорию:", reply_markup=categories_kb(cats))

@router.message(F.text == "/balance")
@router.message(F.text == "💰 Баланс")
async def cmd_balance(message: Message):
    user = await get_user(message.from_user.id)
    if not user:
        await message.answer("❌ Вы не зарегистрированы. Нажмите «📝 Регистрация».")
        return
    _, phone, address, balance, username = user
    uname = username or (message.from_user.full_name or "не указано")
    await message.answer(
        f"📱 Телефон: {phone}\n"
        f"👤 Имя: {uname}\n"
        f"📍 Адрес: {address or 'не указан'}\n"
        f"💰 Баланс: {balance:.2f} ₽\n\n"
        f"Хотите пополнить баланс (фиктивно)? Выберите сумму:",
        reply_markup=balance_topup_kb()
    )

@router.callback_query(F.data.startswith("topup:"))
async def topup_balance(call: CallbackQuery):
    await call.answer()
    try:
        amount = float(call.data.split(":")[1])
    except Exception:
        await call.message.reply_text("Некорректная сумма.")
        return
    await update_balance(call.from_user.id, amount)
    user = await get_user(call.from_user.id)
    new_balance = user[3] if user else 0.0
    await call.message.edit_text(
        f"✅ Баланс пополнен на {amount:.2f} ₽.\nТекущий баланс: {new_balance:.2f} ₽"
    )

@router.message(F.text == "🆘 Помощь")
async def help_message(message: Message):
    await message.answer(
        "Нужна помощь? Свяжитесь с оператором:\n"
        "☎️ +7 927 147-77-02\n"
        "Написать в Telegram: @a1exgolysh"
    )

@router.message(F.text == "🛠 Админ")
@router.message(F.text == "Админ")  # на случай ручного ввода
async def admin_menu(message: Message):
    if not is_admin(message.from_user.id):
        await message.answer("⛔ Доступ запрещён. Добавьте свой user_id в ADMIN_IDS в .env и перезапустите бота.")
        return
    await message.answer("Админ-меню:", reply_markup=admin_menu_kb())
