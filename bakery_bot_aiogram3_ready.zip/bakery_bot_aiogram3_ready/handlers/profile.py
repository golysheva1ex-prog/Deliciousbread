# handlers/profile.py
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State

from db import get_user, set_address, set_username
from keyboards import profile_menu_kb

router = Router(name="profile")

class ProfileStates(StatesGroup):
    edit_address = State()
    edit_username = State()

@router.message(F.text == "👤 Мой профиль")
async def my_profile(message: Message):
    user = await get_user(message.from_user.id)
    if not user:
        await message.answer("❌ Вы не зарегистрированы. Нажмите «📝 Регистрация».")
        return
    _, phone, address, balance, username = user
    uname = username or (message.from_user.full_name or "не указано")
    addr = address or "не указан"
    await message.answer(
        f"👤 Профиль\n"
        f"Имя: {uname}\n"
        f"Телефон: {phone}\n"
        f"Адрес доставки: {addr}\n"
        f"Баланс: {balance:.2f} ₽",
        reply_markup=profile_menu_kb()
    )

@router.callback_query(F.data == "profile:edit_address")
async def profile_edit_address(call: CallbackQuery, state: FSMContext):
    await call.answer()
    await call.message.answer("Введите новый адрес доставки:")
    await state.set_state(ProfileStates.edit_address)

@router.message(ProfileStates.edit_address)
async def profile_set_address(message: Message, state: FSMContext):
    address = message.text.strip()
    if not address:
        await message.answer("Адрес не может быть пустым. Введите снова:")
        return
    await set_address(message.from_user.id, address)
    await state.clear()
    await message.answer("✅ Адрес доставки обновлён. Нажмите «👤 Мой профиль» для просмотра.")

@router.callback_query(F.data == "profile:edit_username")
async def profile_edit_username(call: CallbackQuery, state: FSMContext):
    await call.answer()
    await call.message.answer("Введите новое имя (как отображать в заказах):")
    await state.set_state(ProfileStates.edit_username)

@router.message(ProfileStates.edit_username)
async def profile_set_username(message: Message, state: FSMContext):
    uname = message.text.strip()
    if not uname:
        await message.answer("Имя не может быть пустым. Введите снова:")
        return
    await set_username(message.from_user.id, uname)
    await state.clear()
    await message.answer("✅ Имя обновлено. Нажмите «👤 Мой профиль» для просмотра.")
