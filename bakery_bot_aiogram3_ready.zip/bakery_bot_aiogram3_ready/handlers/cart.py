# handlers/cart.py
from aiogram import Router, F
from aiogram.types import Message, CallbackQuery
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import StatesGroup, State

from db import get_user, get_cart, clear_cart, create_order, set_order_status, set_address
from keyboards import cart_controls_kb, checkout_confirm_kb

router = Router(name="cart")

class CheckoutStates(StatesGroup):
    change_address = State()

def format_cart(items) -> str:
    if not items:
        return "🧺 Ваша корзина пуста."
    lines = ["🧺 Корзина:"]
    total = 0.0
    for product_id, qty, title, price in items:
        line = f"• {title} × {qty} = {qty * price:.2f} ₽"
        lines.append(line)
        total += qty * price
    lines.append(f"\nИтого: {total:.2f} ₽")
    return "\n".join(lines)

@router.message(F.text == "🧺 Корзина")
async def show_cart(message: Message):
    items = await get_cart(message.from_user.id)
    if not items:
        await message.answer("🧺 Корзина пуста.")
        return
    await message.answer(format_cart(items), reply_markup=cart_controls_kb())

@router.callback_query(F.data == "cart:clear")
async def clear_cart_cb(call: CallbackQuery):
    await clear_cart(call.from_user.id)
    await call.message.edit_text("🧹 Корзина очищена.")

@router.message(F.text == "📦 Оформить заказ")
async def checkout(message: Message, state: FSMContext):
    user = await get_user(message.from_user.id)
    if not user:
        await message.answer("❌ Сначала зарегистрируйтесь: «📝 Регистрация».")
        return
    _, phone, address, _, username = user
    items = await get_cart(message.from_user.id)
    if not items:
        await message.answer("Корзина пуста.")
        return

    addr = address or "не указан"
    await message.answer(
        f"{format_cart(items)}\n\n"
        f"Адрес доставки: {addr}\n"
        f"Подтвердите адрес или измените его.",
        reply_markup=checkout_confirm_kb()
    )

@router.callback_query(F.data == "checkout:confirm_address")
async def checkout_confirm(call: CallbackQuery):
    # Адрес подтвержден — создаем заказ и тут же помечаем «оплачено (фиктивно)»
    user = await get_user(call.from_user.id)
    if not user:
        await call.message.edit_text("❌ Регистрация не найдена.")
        return
    _, _, address, _, _ = user
    items = await get_cart(call.from_user.id)
    if not items:
        await call.message.edit_text("Корзина пуста.")
        return

    order_id = await create_order(call.from_user.id, address or "", items)
    await set_order_status(order_id, "paid")
    await clear_cart(call.from_user.id)

    await call.message.edit_text(
        f"✅ Оплата получена (фиктивно).\n"
        f"Заказ №{order_id} принят в работу!\n"
        f"Доставка по адресу: {address or 'не указан'}"
    )

@router.callback_query(F.data == "checkout:change_address")
async def checkout_change_address(call: CallbackQuery, state: FSMContext):
    await call.answer()
    await call.message.reply_text("Введите новый адрес доставки:")
    await state.set_state(CheckoutStates.change_address)

@router.message(CheckoutStates.change_address)
async def checkout_apply_new_address(message: Message, state: FSMContext):
    new_address = message.text.strip()
    if not new_address:
        await message.answer("Адрес не может быть пустым. Введите снова:")
        return

    await set_address(message.from_user.id, new_address)

    # После изменения адреса — сразу создаем заказ и «оплачиваем» (фиктивно)
    user = await get_user(message.from_user.id)
    items = await get_cart(message.from_user.id)
    if not items:
        await message.answer("Корзина пуста.")
        await state.clear()
        return

    order_id = await create_order(message.from_user.id, new_address, items)
    await set_order_status(order_id, "paid")
    await clear_cart(message.from_user.id)

    await state.clear()
    await message.answer(
        f"✅ Оплата получена (фиктивно).\n"
        f"Заказ №{order_id} принят в работу!\n"
        f"Доставка по адресу: {new_address}"
    )

@router.callback_query(F.data == "checkout:cancel")
async def checkout_cancel(call: CallbackQuery):
    await call.message.edit_text("❌ Оформление заказа отменено.")
